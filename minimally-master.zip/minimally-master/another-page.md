---
layout: default
---

## Welcome to another page
<!-- You can also use the # to declare titles of pages. No need to use Frontmatter all the time. If you don't use # then it works as expected i.e it doesn't come up in the side bar -->
_yay_

[back](./)
